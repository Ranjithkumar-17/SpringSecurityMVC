package com.app.service;

import java.util.List;

import com.app.entity.Customers;

public interface CustomerService {

	List<Customers> findAllCustomer();
	Customers findCustomer(String id);
	String saveCustomers();
	String deleteCustomer(String id);
}

