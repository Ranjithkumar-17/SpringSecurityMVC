package com.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.entity.Customers;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Override
	public List<Customers> findAllCustomer() {
		
		return null;
	}

	@Override
	public Customers findCustomer(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String saveCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCustomer(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
