package com.app.entity;

public class Customers {
	
	private long customer_id;
	private String customer_name;
	

}
