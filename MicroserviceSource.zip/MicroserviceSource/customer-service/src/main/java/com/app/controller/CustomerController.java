package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Customers;
import com.app.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService service;
	
	@GetMapping("/customer")
	ResponseEntity<List<Customers>> fetchEmployee(){
		
		service.findAllCustomer();
		
		return null;
	}
	
	@GetMapping("/customer/{id}")
	ResponseEntity<List<Customers>> fetchEmployee(@PathVariable String id){
		
		service.findCustomer(id);
		
		return null;
	}
	
	@DeleteMapping("/customer/{id}")
	ResponseEntity<List<Customers>> deleteEmployee(@PathVariable String id){
		
		service.deleteCustomer(id);
		
		return null;
	}
	
	@PostMapping("/customer")
	ResponseEntity<List<Customers>> saveEmployee(@RequestBody Customers emp){
		
		service.saveCustomers();
		
		return null;
	}
}
