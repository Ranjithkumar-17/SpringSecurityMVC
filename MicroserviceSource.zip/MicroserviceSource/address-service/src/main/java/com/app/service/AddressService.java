package com.app.service;

import java.util.List;

import com.app.entity.Address;

public interface AddressService {
	
	List<Address> findAllAddress();
	Address findAddresById(String id);
	String saveAddres();
	String deleteAddres(String id);
}
