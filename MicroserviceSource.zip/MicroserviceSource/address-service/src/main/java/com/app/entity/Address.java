package com.app.entity;

public class Address {

	private long address_id;
	private String door_no;
	private String street;
	private String area;
}
