package com.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.entity.Address;

@Service
public class AddressServiceImpl implements AddressService {

	@Override
	public List<Address> findAllAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Address findAddresById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String saveAddres() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteAddres(String id) {
		// TODO Auto-generated method stub
		return null;
	}


}
