package com.app.service;

import java.util.List;

import com.app.entity.Employees;

public interface EmployeeService {
	
	List<Employees> findAllEmployee();
	Employees findEmployee(String id);
	String saveEmployee();
	String deleteEmployee(String id);

}
