package com.app.entity;

import javax.persistence.Entity;

@Entity
public class Employees {

	private long employee_id;
	private String employee_name;
}
