package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Employees;
import com.app.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
	@GetMapping("/employee")
	ResponseEntity<List<Employees>> fetchEmployee(){
		
		service.findAllEmployee();
		
		return null;
	}
	
	@GetMapping("/employee/{id}")
	ResponseEntity<List<Employees>> fetchEmployee(@PathVariable String id){
		
		service.findEmployee(id);
		
		return null;
	}
	
	@DeleteMapping("/employee/{id}")
	ResponseEntity<List<Employees>> deleteEmployee(@PathVariable String id){
		
		service.deleteEmployee(id);
		
		return null;
	}
	
	@PostMapping("/employee")
	ResponseEntity<List<Employees>> saveEmployee(@RequestBody Employees emp){
		
		service.saveEmployee();
		
		return null;
	}
}
