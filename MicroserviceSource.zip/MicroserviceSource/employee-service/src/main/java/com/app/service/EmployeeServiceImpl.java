package com.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.entity.Employees;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public List<Employees> findAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employees findEmployee(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String saveEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
