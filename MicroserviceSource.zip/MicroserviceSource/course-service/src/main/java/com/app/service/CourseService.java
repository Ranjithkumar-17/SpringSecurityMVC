package com.app.service;

import java.util.List;

import com.app.entity.Courses;

public interface CourseService {

	List<Courses> findAllCourse();
	Courses findCourse(String id);
	String saveCourse();
	String deleteCourses(String id);
}
