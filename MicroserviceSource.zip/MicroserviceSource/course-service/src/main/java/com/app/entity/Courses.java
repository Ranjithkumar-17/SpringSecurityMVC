package com.app.entity;

public class Courses {

}
