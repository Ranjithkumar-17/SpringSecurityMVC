package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Courses;
import com.app.service.CourseService;

@RestController
public class CourseController {
	
	@Autowired
	CourseService service;
	
	@GetMapping("/courses")
	ResponseEntity<List<Courses>> fetchEmployee(){
		
		service.findAllCourse();
		
		return null;
	}	
	
	@GetMapping("/course/{id}")
	ResponseEntity<List<Courses>> fetchEmployee(@PathVariable String id){
		
		service.findCourse(id);
		
		return null;
	}
	
	@DeleteMapping("/course/{id}")
	ResponseEntity<List<Courses>> deleteEmployee(@PathVariable String id){
		
		service.deleteCourses(id);
		
		return null;
	}
	
	@PostMapping("/course")
	ResponseEntity<List<Courses>> saveEmployee(@RequestBody Courses emp){
		
		service.saveCourse();
		
		return null;
	}
}
